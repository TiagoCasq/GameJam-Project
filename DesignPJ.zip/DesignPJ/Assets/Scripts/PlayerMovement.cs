using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{

    
    [SerializeField] private InputAction action;
    
    [SerializeField] private float velocity;

    private Vector2 movement = new Vector2(0, 0);
    
    private Rigidbody rb;
  
    void Awake()
    {
        
        rb = GetComponent<Rigidbody>();


    }

    void Move()
    {

        

    }


    // Update is called once per frame
    void Update()
    {
        
        if(action )

    }


}
